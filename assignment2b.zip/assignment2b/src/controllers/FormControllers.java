package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import beans.User;

@ManagedBean
@ViewScoped
public class FormControllers {
		public String onSubmit(User user)
		{
			//forward the response to the test response
			FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("User", user);
			return "TestResponse.xhtml";
		}
}
